package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val content: String,
    val subjectTag: String,
    val semester: Int = 6,
    val isPinned: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "attendance")
data class AttendanceEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subjectCode: String,
    val subjectName: String,
    val attendedClasses: Int,
    val totalClasses: Int,
    val targetPercentage: Int = 75,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "student_profile")
data class ProfileEntity(
    @PrimaryKey val id: Int = 1,
    val name: String,
    val rollNo: String,
    val regNo: String,
    val departmentCode: String,
    val semester: Int,
    val shiftCode: String,
    val session: String,
    val bloodGroup: String,
    val phone: String,
    val email: String
)
