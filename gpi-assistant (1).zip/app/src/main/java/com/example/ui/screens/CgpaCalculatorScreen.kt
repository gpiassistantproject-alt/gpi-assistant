package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DemoData
import com.example.model.AppLanguage
import com.example.ui.components.DemoDisclaimerBanner
import com.example.ui.theme.EmeraldGreenDark
import com.example.ui.theme.EmeraldGreenPrimary

data class SubjectGpaRow(
    val name: String,
    val credit: String,
    val gradePoint: String
)

@Composable
fun CgpaCalculatorScreen(
    language: AppLanguage
) {
    val isBn = language == AppLanguage.BANGLA
    var selectedTab by remember { mutableIntStateOf(0) }

    // Cumulative CGPA state (8 semesters)
    val semesterGpas = remember {
        mutableStateListOf(
            "3.65", "3.75", "3.80", "3.70", "3.85", "3.90", "", ""
        )
    }

    // Single Semester GPA state (dynamic subject rows)
    val subjectRows = remember {
        mutableStateListOf(
            SubjectGpaRow("66661 Database Application", "4", "4.00"),
            SubjectGpaRow("66662 Web Development", "4", "3.75"),
            SubjectGpaRow("66663 Data Communication", "3", "3.50"),
            SubjectGpaRow("66664 Microcontroller & Embedded", "3", "3.75"),
            SubjectGpaRow("66867 Industrial Management", "2", "4.00")
        )
    }

    // Cumulative CGPA calculation using official BTEB weightage
    val calculatedCumulativeCgpa = remember(semesterGpas.toList()) {
        var totalWeightedGpa = 0.0
        var totalWeight = 0.0

        DemoData.btebWeightages.forEachIndexed { index, (_, weight) ->
            val gpaStr = semesterGpas.getOrNull(index)?.trim() ?: ""
            val gpaVal = gpaStr.toDoubleOrNull()
            if (gpaVal != null && gpaVal in 2.0..4.0) {
                totalWeightedGpa += gpaVal * weight
                totalWeight += weight
            }
        }

        if (totalWeight > 0.0) {
            totalWeightedGpa / totalWeight
        } else {
            0.0
        }
    }

    // Single Semester GPA calculation: Sum(Credit * GP) / Sum(Credit)
    val calculatedSemesterGpa = remember(subjectRows.toList()) {
        var totalQualityPoints = 0.0
        var totalCredits = 0.0

        subjectRows.forEach { row ->
            val cr = row.credit.toDoubleOrNull() ?: 0.0
            val gp = row.gradePoint.toDoubleOrNull() ?: 0.0
            if (cr > 0 && gp in 0.0..4.0) {
                totalQualityPoints += (cr * gp)
                totalCredits += cr
            }
        }

        if (totalCredits > 0.0) totalQualityPoints / totalCredits else 0.0
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Tab Row
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = EmeraldGreenPrimary,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = EmeraldGreenPrimary
                )
            }
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = {
                    Text(
                        text = if (isBn) "মোট সিজিপিএ (৮ পর্ব)" else "Cumulative CGPA",
                        fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 12.5.sp
                    )
                },
                modifier = Modifier.testTag("cgpa_tab_cumulative")
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = {
                    Text(
                        text = if (isBn) "সেমিস্টার জিপিএ" else "Semester GPA",
                        fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 12.5.sp
                    )
                },
                modifier = Modifier.testTag("cgpa_tab_semester")
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = {
                    Text(
                        text = if (isBn) "গ্রেডিং স্কেল" else "Grading Scale",
                        fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 12.5.sp
                    )
                },
                modifier = Modifier.testTag("cgpa_tab_scale")
            )
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (selectedTab == 0) {
                // Tab 1: Cumulative 8 Semesters CGPA
                item {
                    // Result Header Card
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = EmeraldGreenDark,
                        shadowElevation = 3.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("cgpa_cumulative_result_card")
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(20.dp)
                        ) {
                            Text(
                                text = if (isBn) "কারিগরি বোর্ড প্রবিধান অনুযায়ী সিজিপিএ" else "BTEB Probidhan Cumulative CGPA",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = Color(0xFF6EE7B7),
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (calculatedCumulativeCgpa > 0.0) String.format("%.2f", calculatedCumulativeCgpa) else "0.00",
                                style = MaterialTheme.typography.displayMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White,
                                    fontSize = 44.sp
                                )
                            )
                            Text(
                                text = "সর্বমোট ৪.০০ স্কেলে",
                                style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.8f))
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.White.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = if (calculatedCumulativeCgpa >= 3.00) "১ম বিভাগ / First Division (Passed)" else "চলমান মূল্যায়ন / Ongoing Evaluation",
                                    style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFFD1FAE5), fontWeight = FontWeight.Bold),
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }

                item {
                    Text(
                        text = if (isBn) "প্রতি পর্বের জিপিএ লিখুন (১ম থেকে ৮ম পর্ব)" else "Enter GPA for Each Semester (1st to 8th)",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }

                // 8 Semester Inputs
                items(DemoData.btebWeightages.size) { index ->
                    val (semNum, weight) = DemoData.btebWeightages[index]
                    val semLabel = if (isBn) {
                        when (semNum) {
                            1 -> "১ম পর্ব (${(weight * 100).toInt()}%)"
                            2 -> "২য় পর্ব (${(weight * 100).toInt()}%)"
                            3 -> "৩য় পর্ব (${(weight * 100).toInt()}%)"
                            4 -> "৪র্থ পর্ব (${(weight * 100).toInt()}%)"
                            5 -> "৫ম পর্ব (${(weight * 100).toInt()}%)"
                            6 -> "৬ষ্ঠ পর্ব (${(weight * 100).toInt()}%)"
                            7 -> "৭ম পর্ব (${(weight * 100).toInt()}%)"
                            else -> "৮ম পর্ব (${(weight * 100).toInt()}%)"
                        }
                    } else {
                        "Sem $semNum (${(weight * 100).toInt()}%)"
                    }

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = semLabel,
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                ),
                                modifier = Modifier.weight(1f)
                            )

                            OutlinedTextField(
                                value = semesterGpas.getOrElse(index) { "" },
                                onValueChange = { newValue ->
                                    if (newValue.length <= 4) {
                                        if (index < semesterGpas.size) {
                                            semesterGpas[index] = newValue
                                        }
                                    }
                                },
                                placeholder = { Text("3.75", fontSize = 12.sp) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                shape = RoundedCornerShape(8.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = EmeraldGreenPrimary
                                ),
                                modifier = Modifier
                                    .width(90.dp)
                                    .testTag("cgpa_input_sem_${semNum}")
                            )
                        }
                    }
                }

                item {
                    Button(
                        onClick = {
                            for (i in 0 until semesterGpas.size) {
                                semesterGpas[i] = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("cgpa_reset_button")
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isBn) "সকল মান রিসেট করুন" else "Reset All Inputs", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else if (selectedTab == 1) {
                // Tab 2: Single Semester GPA Calculator
                item {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = Color(0xFF0F766E),
                        shadowElevation = 3.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("semester_gpa_result_card")
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(20.dp)
                        ) {
                            Text(
                                text = if (isBn) "চলতি সেমিস্টার জিপিএ (GPA)" else "Current Semester GPA",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = Color(0xFFCCFBF1),
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (calculatedSemesterGpa > 0.0) String.format("%.2f", calculatedSemesterGpa) else "0.00",
                                style = MaterialTheme.typography.displayMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White,
                                    fontSize = 44.sp
                                )
                            )
                            Text(
                                text = "মোট বিষয়: ${subjectRows.size} টি",
                                style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.85f))
                            )
                        }
                    }
                }

                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (isBn) "বিষয়ের তালিকা (ক্রেডিট ও জিপিএ)" else "Subjects (Credit & Grade Point)",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            modifier = Modifier.weight(1f)
                        )

                        Button(
                            onClick = {
                                subjectRows.add(SubjectGpaRow("New Subject", "3", "3.75"))
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreenPrimary),
                            modifier = Modifier.testTag("add_subject_row_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isBn) "বিষয় যোগ" else "Add")
                        }
                    }
                }

                itemsIndexed(subjectRows) { index, item ->
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                OutlinedTextField(
                                    value = item.name,
                                    onValueChange = { newName ->
                                        subjectRows[index] = item.copy(name = newName)
                                    },
                                    label = { Text(if (isBn) "বিষয়ের নাম / কোড" else "Subject Name", fontSize = 11.sp) },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f)
                                )

                                IconButton(
                                    onClick = {
                                        if (subjectRows.size > 1) {
                                            subjectRows.removeAt(index)
                                        }
                                    },
                                    modifier = Modifier.padding(start = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = Color(0xFFDC2626)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedTextField(
                                    value = item.credit,
                                    onValueChange = { newCr ->
                                        subjectRows[index] = item.copy(credit = newCr)
                                    },
                                    label = { Text("Credit", fontSize = 11.sp) },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.weight(1f)
                                )

                                OutlinedTextField(
                                    value = item.gradePoint,
                                    onValueChange = { newGp ->
                                        subjectRows[index] = item.copy(gradePoint = newGp)
                                    },
                                    label = { Text("Grade Point", fontSize = 11.sp) },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            } else {
                // Tab 3: BTEB Grading Scale Table
                item {
                    Text(
                        text = if (isBn) "বাংলাদেশ কারিগরি শিক্ষা বোর্ড (BTEB) গ্রেডিং সিস্টেম" else "BTEB Official Grading System Reference",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }

                items(DemoData.btebGradingScale) { (marks, letterGrade, gp) ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (letterGrade == "F") Color(0xFFFEE2E2) else Color(0xFFD1FAE5),
                                modifier = Modifier.size(42.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = letterGrade,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.ExtraBold,
                                            color = if (letterGrade == "F") Color(0xFFDC2626) else Color(0xFF065F46)
                                        )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "নম্বর প্রাপ্তি: $marks",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                )
                                Text(
                                    text = "গ্রেড পয়েন্ট: $gp",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }
                    }
                }
            }

            item {
                DemoDisclaimerBanner(language = language)
            }
        }
    }
}
