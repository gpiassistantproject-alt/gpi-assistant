package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.model.AppLanguage
import com.example.model.ScreenRoute
import com.example.model.StudentProfile
import com.example.ui.components.DemoDisclaimerBanner
import com.example.ui.theme.BentoBlueContainer
import com.example.ui.theme.BentoBlueDark
import com.example.ui.theme.BentoBlueLight
import com.example.ui.theme.BentoBluePrimary
import com.example.ui.theme.BentoCyanBg
import com.example.ui.theme.BentoCyanFg
import com.example.ui.theme.BentoGreenBg
import com.example.ui.theme.BentoGreenFg
import com.example.ui.theme.BentoIndigoBg
import com.example.ui.theme.BentoIndigoFg
import com.example.ui.theme.BentoOrangeBg
import com.example.ui.theme.BentoOrangeFg
import com.example.ui.theme.BentoPurpleBg
import com.example.ui.theme.BentoPurpleFg
import com.example.ui.theme.BentoRedBg
import com.example.ui.theme.BentoRedFg
import com.example.ui.theme.BentoRoseBg
import com.example.ui.theme.BentoRoseFg
import com.example.ui.theme.BentoSlateBg
import com.example.ui.theme.BentoSlateFg
import com.example.ui.theme.BentoYellowBg
import com.example.ui.theme.BentoYellowFg

@Composable
fun HomeScreen(
    profile: StudentProfile,
    language: AppLanguage,
    onNavigate: (ScreenRoute) -> Unit,
    onQuickAiQuery: (String) -> Unit
) {
    var quickQueryText by remember { mutableStateOf("") }
    val isBn = language == AppLanguage.BANGLA

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("home_screen_container"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Bento Hero Section - Blue-600 rounded-3xl with welcoming card & campus backdrop
        item {
            Card(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = BentoBluePrimary
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_hero_card")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                ) {
                    // Campus banner photo background
                    AsyncImage(
                        model = R.drawable.gpi_campus_banner_1786807668827,
                        contentDescription = "Gopalganj Polytechnic Campus",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    )

                    // Bento Gradient overlay
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0x991E3A8A),
                                        Color(0xF21D4ED8)
                                    )
                                )
                            )
                    )

                    // Decorative geometric orb
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .size(110.dp)
                            .background(Color.White.copy(alpha = 0.08f), CircleShape)
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color.White.copy(alpha = 0.2f),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.School,
                                        contentDescription = "GPI",
                                        tint = Color.White,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = if (isBn) "গোপালগঞ্জ পলিটেকনিক ইনস্টিটিউট" else "Gopalganj Polytechnic Institute",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        color = BentoBlueContainer,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        letterSpacing = 0.5.sp
                                    )
                                )
                                Text(
                                    text = if (isBn) "আসসালামু আলাইকুম," else "Assalamu Alaikum,",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = Color.White.copy(alpha = 0.85f),
                                        fontSize = 12.sp
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = if (isBn) "আজকের ক্লাসে স্বাগতম, ${profile.name}!" else "Welcome back, ${profile.name}!",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.White.copy(alpha = 0.18f)
                            ) {
                                Text(
                                    text = if (isBn) profile.department.nameBn else profile.department.nameEn,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = Color.White,
                                        fontWeight = FontWeight.SemiBold
                                    ),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = BentoBlueContainer.copy(alpha = 0.9f)
                            ) {
                                Text(
                                    text = if (isBn) "${profile.semester}ষ্ঠ পর্ব • ${profile.shift.nameBn}" else "Sem ${profile.semester} • ${profile.shift.nameEn}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = BentoBlueDark,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Bento AI Quick Ask Bar
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp,
                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_quick_ai_bar")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = BentoIndigoBg,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "AI",
                                    tint = BentoIndigoFg,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isBn) "এআই টিউটরকে সরাসরি প্রশ্ন করুন" else "Ask AI Academic Tutor",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 13.5.sp
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = quickQueryText,
                            onValueChange = { quickQueryText = it },
                            placeholder = {
                                Text(
                                    text = if (isBn) "যেমন: ডাটাবেস 3NF কি? ওহমের সূত্র..." else "e.g., Explain 3NF normalization, Ohm's law...",
                                    fontSize = 12.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BentoBluePrimary,
                                unfocusedBorderColor = Color(0xFFE2E8F0)
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("home_quick_ai_input")
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = {
                                if (quickQueryText.isNotBlank()) {
                                    onQuickAiQuery(quickQueryText)
                                    quickQueryText = ""
                                } else {
                                    onNavigate(ScreenRoute.AI_TUTOR)
                                }
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .background(BentoBluePrimary, RoundedCornerShape(14.dp))
                                .testTag("home_quick_ai_send_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Ask AI",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }

        // Bento Section Title
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp, bottom = 2.dp)
            ) {
                Text(
                    text = if (isBn) "অ্যাকাডেমিক মডিউল" else "Academic Modules",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 16.sp
                    )
                )
                Spacer(modifier = Modifier.weight(1f))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = BentoBlueContainer
                ) {
                    Text(
                        text = if (isBn) "৯টি সেবা" else "9 Services",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = BentoBlueDark,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.5.sp
                        ),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
        }

        // BENTO GRID ROW 1: AI Tutor (Span 2) + Notes (Span 1)
        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // AI Tutor Bento Card (Span 2 / Weight 2f)
                Surface(
                    onClick = { onNavigate(ScreenRoute.AI_TUTOR) },
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 1.dp,
                    border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
                    modifier = Modifier
                        .weight(2f)
                        .height(115.dp)
                        .testTag("feature_card_ai_tutor")
                ) {
                    Column(
                        verticalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = BentoIndigoBg,
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = if (isBn) "এআই" else "AI",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        color = BentoIndigoFg,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                )
                            }
                        }

                        Column {
                            Text(
                                text = if (isBn) "এআই টিউটর" else "AI Tutor",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (isBn) "যেকোনো প্রশ্ন করুন" else "Ask any question",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 10.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }
                }

                // Notes Bento Card (Span 1 / Weight 1f)
                Surface(
                    onClick = { onNavigate(ScreenRoute.NOTES) },
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 1.dp,
                    border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
                    modifier = Modifier
                        .weight(1f)
                        .height(115.dp)
                        .testTag("feature_card_notes")
                ) {
                    Column(
                        verticalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = BentoOrangeBg,
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Description,
                                    contentDescription = "Notes",
                                    tint = BentoOrangeFg,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Text(
                            text = if (isBn) "নোটস" else "Notes",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // BENTO GRID ROW 2: Syllabus + Class Routine + Exam Routine (3 cols)
        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Syllabus Bento Card
                BentoSmallCard(
                    title = if (isBn) "সিলেবাস" else "Syllabus",
                    icon = Icons.Default.MenuBook,
                    bgColor = BentoGreenBg,
                    fgColor = BentoGreenFg,
                    testTag = "feature_card_syllabus",
                    onClick = { onNavigate(ScreenRoute.SYLLABUS) },
                    modifier = Modifier.weight(1f)
                )

                // Class Routine Bento Card
                BentoSmallCard(
                    title = if (isBn) "রুটিন" else "Routine",
                    icon = Icons.Default.Schedule,
                    bgColor = BentoPurpleBg,
                    fgColor = BentoPurpleFg,
                    testTag = "feature_card_class_routine",
                    onClick = { onNavigate(ScreenRoute.CLASS_ROUTINE) },
                    modifier = Modifier.weight(1f)
                )

                // Exam Routine Bento Card
                BentoSmallCard(
                    title = if (isBn) "পরীক্ষা" else "Exam",
                    icon = Icons.Default.CalendarMonth,
                    bgColor = BentoRedBg,
                    fgColor = BentoRedFg,
                    testTag = "feature_card_exam_routine",
                    onClick = { onNavigate(ScreenRoute.EXAM_ROUTINE) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // BENTO GRID ROW 3: Notice + CGPA + Attendance (3 cols)
        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Notice Board Bento Card
                BentoSmallCard(
                    title = if (isBn) "নোটিশ" else "Notice",
                    icon = Icons.Default.Notifications,
                    bgColor = BentoYellowBg,
                    fgColor = BentoYellowFg,
                    testTag = "feature_card_notice_board",
                    onClick = { onNavigate(ScreenRoute.NOTICE_BOARD) },
                    modifier = Modifier.weight(1f)
                )

                // CGPA Calculator Bento Card
                BentoSmallCard(
                    title = if (isBn) "সিজিপিএ" else "CGPA",
                    icon = Icons.Default.Calculate,
                    bgColor = BentoCyanBg,
                    fgColor = BentoCyanFg,
                    testTag = "feature_card_cgpa_calculator",
                    onClick = { onNavigate(ScreenRoute.CGPA_CALCULATOR) },
                    modifier = Modifier.weight(1f)
                )

                // Attendance Tracker Bento Card
                BentoSmallCard(
                    title = if (isBn) "উপস্থিতি" else "Attendance",
                    icon = Icons.Default.CheckCircle,
                    bgColor = BentoRoseBg,
                    fgColor = BentoRoseFg,
                    testTag = "feature_card_attendance_tracker",
                    onClick = { onNavigate(ScreenRoute.ATTENDANCE_TRACKER) },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // BENTO GRID ROW 4: Student Profile (Span 3 / Full Width)
        item {
            Surface(
                onClick = { onNavigate(ScreenRoute.STUDENT_PROFILE) },
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp,
                border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("feature_card_student_profile")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = BentoSlateBg,
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = "Profile",
                                tint = BentoSlateFg,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isBn) "আমার প্রোফাইল (${profile.name})" else "Student Profile (${profile.name})",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (isBn) "${profile.department.nameBn} • ${profile.semester}ষ্ঠ পর্ব" else "${profile.department.nameEn} • Sem ${profile.semester}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }

                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "Open Profile",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Bento Today Status Highlight Row
        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Next Class Widget Bento Card
                Surface(
                    onClick = { onNavigate(ScreenRoute.CLASS_ROUTINE) },
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    shadowElevation = 1.dp,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("home_widget_routine")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = BentoGreenBg,
                                modifier = Modifier.size(24.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Schedule,
                                        contentDescription = "Class",
                                        tint = BentoGreenFg,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isBn) "পরবর্তী ক্লাস" else "Next Class",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = BentoGreenFg,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "66661 • Database Lab",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 12.5.sp
                            )
                        )
                        Text(
                            text = if (isBn) "ল্যাব ২০১ • ০৮:০০ AM" else "Lab 201 • 08:00 AM",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 10.5.sp
                            )
                        )
                    }
                }

                // Attendance Status Widget Bento Card
                Surface(
                    onClick = { onNavigate(ScreenRoute.ATTENDANCE_TRACKER) },
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    shadowElevation = 1.dp,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("home_widget_attendance")
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = BentoCyanBg,
                                modifier = Modifier.size(24.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Attendance",
                                        tint = BentoCyanFg,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isBn) "গড় উপস্থিতি" else "Attendance",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = BentoCyanFg,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "86.4% (নিরাপদ)",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 12.5.sp
                            )
                        )
                        Text(
                            text = if (isBn) "৭৫% এর উপরে রয়েছে" else "Above 75% minimum",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 10.5.sp
                            )
                        )
                    }
                }
            }
        }

        // Demo disclaimer footer
        item {
            DemoDisclaimerBanner(language = language, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
fun BentoSmallCard(
    title: String,
    icon: ImageVector,
    bgColor: Color,
    fgColor: Color,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(22.dp),
        color = MaterialTheme.colorScheme.surface,
        shadowElevation = 1.dp,
        border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
        modifier = modifier
            .height(105.dp)
            .testTag(testTag)
    ) {
        Column(
            verticalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = bgColor,
                modifier = Modifier.size(38.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = fgColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                ),
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
