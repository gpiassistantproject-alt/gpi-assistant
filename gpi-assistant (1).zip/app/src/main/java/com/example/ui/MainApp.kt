package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.ScreenRoute
import com.example.ui.components.AppTopBar
import com.example.ui.screens.AiTutorScreen
import com.example.ui.screens.AttendanceTrackerScreen
import com.example.ui.screens.CgpaCalculatorScreen
import com.example.ui.screens.ClassRoutineScreen
import com.example.ui.screens.ExamRoutineScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NotesScreen
import com.example.ui.screens.NoticeBoardScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SyllabusScreen
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import com.example.ui.theme.BentoBlueContainer
import com.example.ui.theme.BentoBluePrimary
import com.example.viewmodel.GpiViewModel

@Composable
fun MainApp(viewModel: GpiViewModel) {
    val currentRoute by viewModel.currentRoute.collectAsState()
    val language by viewModel.language.collectAsState()
    val profile by viewModel.profile.collectAsState()
    val notes by viewModel.notes.collectAsState()
    val attendanceList by viewModel.attendanceList.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()
    val isAiLoading by viewModel.isAiLoading.collectAsState()

    val isBn = language == AppLanguage.BANGLA

    // System Back Press handling
    BackHandler(enabled = currentRoute != ScreenRoute.HOME) {
        viewModel.navigateBack()
    }

    val screenTitle = when (currentRoute) {
        ScreenRoute.HOME -> if (isBn) "GPI Assistant" else "GPI Assistant"
        ScreenRoute.AI_TUTOR -> if (isBn) "এআই অ্যাকাডেমিক টিউটর" else "AI Academic Tutor"
        ScreenRoute.NOTES -> if (isBn) "নোটস ও হ্যান্ডআউট" else "Lecture & Study Notes"
        ScreenRoute.SYLLABUS -> if (isBn) "বিটিইবি সিলেবাস" else "BTEB Syllabus"
        ScreenRoute.CLASS_ROUTINE -> if (isBn) "ক্লাস রুটিন" else "Class Routine"
        ScreenRoute.EXAM_ROUTINE -> if (isBn) "পরীক্ষার সময়সূচি" else "Exam Routine"
        ScreenRoute.NOTICE_BOARD -> if (isBn) "নোটিশ বোর্ড" else "Notice Board"
        ScreenRoute.CGPA_CALCULATOR -> if (isBn) "সিজিপিএ ক্যালকুলেটর" else "CGPA Calculator"
        ScreenRoute.ATTENDANCE_TRACKER -> if (isBn) "উপস্থিতি ট্র্যাকার" else "Attendance Tracker"
        ScreenRoute.STUDENT_PROFILE -> if (isBn) "শিক্ষার্থী প্রোফাইল" else "Student Profile"
    }

    val screenSubtitle = when (currentRoute) {
        ScreenRoute.HOME -> if (isBn) "গোপালগঞ্জ পলিটেকনিক ইনস্টিটিউট" else "Gopalganj Polytechnic Institute"
        else -> null
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            AppTopBar(
                title = screenTitle,
                subtitle = screenSubtitle,
                showBackButton = currentRoute != ScreenRoute.HOME,
                language = language,
                onBackClick = { viewModel.navigateBack() },
                onLanguageToggle = { viewModel.toggleLanguage() }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 4.dp,
                modifier = Modifier
                    .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                    .testTag("app_bottom_navigation")
            ) {
                val navItems = listOf(
                    Triple(ScreenRoute.HOME, if (isBn) "হোম" else "Home", Icons.Default.Home),
                    Triple(ScreenRoute.AI_TUTOR, if (isBn) "এআই টিউটর" else "AI Tutor", Icons.Default.AutoAwesome),
                    Triple(ScreenRoute.CLASS_ROUTINE, if (isBn) "রুটিন" else "Routine", Icons.Default.Schedule),
                    Triple(ScreenRoute.STUDENT_PROFILE, if (isBn) "প্রোফাইল" else "Profile", Icons.Default.Person)
                )

                navItems.forEach { (route, label, icon) ->
                    val isSelected = currentRoute == route
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.navigateTo(route) },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = label,
                                tint = if (isSelected) BentoBluePrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        label = {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 11.sp,
                                    color = if (isSelected) BentoBluePrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BentoBluePrimary,
                            selectedTextColor = BentoBluePrimary,
                            indicatorColor = BentoBlueContainer
                        ),
                        modifier = Modifier.testTag("bottom_nav_${route.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentRoute) {
                ScreenRoute.HOME -> {
                    HomeScreen(
                        profile = profile,
                        language = language,
                        onNavigate = { viewModel.navigateTo(it) },
                        onQuickAiQuery = { query ->
                            viewModel.navigateTo(ScreenRoute.AI_TUTOR)
                            viewModel.sendAiPrompt(query)
                        }
                    )
                }
                ScreenRoute.AI_TUTOR -> {
                    AiTutorScreen(
                        messages = chatMessages,
                        isLoading = isAiLoading,
                        language = language,
                        onSendMessage = { viewModel.sendAiPrompt(it) },
                        onClearChat = { viewModel.clearAiChat() }
                    )
                }
                ScreenRoute.NOTES -> {
                    NotesScreen(
                        notes = notes,
                        language = language,
                        onAddNote = { title, content, tag -> viewModel.addNote(title, content, tag) },
                        onDeleteNote = { viewModel.deleteNote(it) },
                        onTogglePin = { viewModel.togglePinNote(it) }
                    )
                }
                ScreenRoute.SYLLABUS -> {
                    SyllabusScreen(
                        language = language,
                        onAskAiAboutSubject = { query ->
                            viewModel.navigateTo(ScreenRoute.AI_TUTOR)
                            viewModel.sendAiPrompt(query)
                        }
                    )
                }
                ScreenRoute.CLASS_ROUTINE -> {
                    ClassRoutineScreen(
                        language = language
                    )
                }
                ScreenRoute.EXAM_ROUTINE -> {
                    ExamRoutineScreen(
                        language = language
                    )
                }
                ScreenRoute.NOTICE_BOARD -> {
                    NoticeBoardScreen(
                        language = language
                    )
                }
                ScreenRoute.CGPA_CALCULATOR -> {
                    CgpaCalculatorScreen(
                        language = language
                    )
                }
                ScreenRoute.ATTENDANCE_TRACKER -> {
                    AttendanceTrackerScreen(
                        attendanceList = attendanceList,
                        language = language,
                        onLogAttendance = { entity, isPresent -> viewModel.logAttendance(entity, isPresent) },
                        onResetAttendance = { viewModel.resetAttendance(it) },
                        onAddSubject = { code, name -> viewModel.addSubjectAttendance(code, name) },
                        onDeleteSubject = { viewModel.deleteAttendanceSubject(it) }
                    )
                }
                ScreenRoute.STUDENT_PROFILE -> {
                    ProfileScreen(
                        profile = profile,
                        language = language,
                        onUpdateProfile = { viewModel.updateProfile(it) }
                    )
                }
            }
        }
    }
}
