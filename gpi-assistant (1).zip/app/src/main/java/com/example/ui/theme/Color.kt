package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Bento Grid Theme Primary & Secondary Colors
val BentoBluePrimary = Color(0xFF2563EB)
val BentoBlueDark = Color(0xFF1D4ED8)
val BentoBlueLight = Color(0xFF3B82F6)
val BentoBlueContainer = Color(0xFFDBEAFE)
val OnBentoBlueContainer = Color(0xFF1E40AF)

// Bento Card Accent Colors (Pastel Containers + Vibrant Foreground)
val BentoIndigoBg = Color(0xFFEEF2FF)
val BentoIndigoFg = Color(0xFF4F46E5)

val BentoOrangeBg = Color(0xFFFFF7ED)
val BentoOrangeFg = Color(0xFFEA580C)

val BentoGreenBg = Color(0xFFF0FDF4)
val BentoGreenFg = Color(0xFF16A34A)

val BentoPurpleBg = Color(0xFFFAF5FF)
val BentoPurpleFg = Color(0xFF9333EA)

val BentoRedBg = Color(0xFFFEF2F2)
val BentoRedFg = Color(0xFFDC2626)

val BentoYellowBg = Color(0xFFFEFCE8)
val BentoYellowFg = Color(0xFFCA8A04)

val BentoCyanBg = Color(0xFFECFEFF)
val BentoCyanFg = Color(0xFF0891B2)

val BentoRoseBg = Color(0xFFFFF1F2)
val BentoRoseFg = Color(0xFFE11D48)

val BentoSlateBg = Color(0xFFF8FAFC)
val BentoSlateFg = Color(0xFF475569)

val AmberAccent = Color(0xFFD97706)
val AmberContainer = Color(0xFFFEF3C7)

// Backward compatibility alias for any existing references
val EmeraldGreenPrimary = BentoBluePrimary
val EmeraldGreenLight = BentoBlueLight
val EmeraldGreenDark = BentoBlueDark
val EmeraldGreenContainer = BentoBlueContainer
val OnEmeraldGreenContainer = OnBentoBlueContainer
val DeepTealSecondary = Color(0xFF0F766E)
val DeepTealContainer = Color(0xFFCCFBF1)
val OnDeepTealContainer = Color(0xFF115E59)
val EngineeringBlueTertiary = Color(0xFF4F46E5)
val EngineeringBlueContainer = Color(0xFFEEF2FF)
val OnEngineeringBlueContainer = Color(0xFF3730A3)

// Dark / Light Scheme Definitions
val DarkSurface = Color(0xFF0F172A)
val DarkBackground = Color(0xFF0B0F19)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkPrimary = Color(0xFF60A5FA)
val DarkSecondary = Color(0xFF818CF8)
val DarkTertiary = Color(0xFF38BDF8)

val LightBackground = Color(0xFFF3F6FA) // Bento Grid Canvas Background
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF64748B)
val LightOutline = Color(0xFFE2E8F0)

