package com.example.model

enum class AppLanguage {
    BANGLA,
    ENGLISH
}

enum class Department(val code: String, val nameEn: String, val nameBn: String) {
    COMPUTER("CST", "Computer Science & Tech", "কম্পিউটার সায়েন্স"),
    CIVIL("CIVIL", "Civil Technology", "সিভিল টেকনোলজি"),
    ELECTRICAL("EEE", "Electrical Technology", "ইলেকট্রিক্যাল টেকনোলজি"),
    MECHANICAL("MECH", "Mechanical Technology", "মেকানিক্যাল টেকনোলজি"),
    ELECTRONICS("ENT", "Electronics Technology", "ইলেকট্রনিক্স টেকনোলজি"),
    RAC("RAC", "Refrigeration & AC", "আর.এ.সি টেকনোলজি"),
    AIDT("AIDT", "Architecture & Interior", "আর্কিটেকচার"),
    TELECOM("TELE", "Telecommunication", "টেলিকমিউনিকেশন")
}

enum class Shift(val code: String, val nameEn: String, val nameBn: String) {
    FIRST("1st", "1st Shift", "১ম শিফট"),
    SECOND("2nd", "2nd Shift", "২য় শিফট")
}

data class StudentProfile(
    val id: Int = 1,
    val name: String = "মোঃ সাজিদ হাসান",
    val rollNo: String = "612345",
    val regNo: String = "1502398471",
    val department: Department = Department.COMPUTER,
    val semester: Int = 6,
    val shift: Shift = Shift.FIRST,
    val session: String = "2021-2022",
    val bloodGroup: String = "B+",
    val phone: String = "+880 1700-000000",
    val email: String = "student@gpi.edu.bd",
    val instituteName: String = "Gopalganj Polytechnic Institute (গোপালগঞ্জ পলিটেকনিক ইনস্টিটিউট)"
)

data class NoticeItem(
    val id: String,
    val titleEn: String,
    val titleBn: String,
    val categoryEn: String,
    val categoryBn: String,
    val dateEn: String,
    val dateBn: String,
    val contentEn: String,
    val contentBn: String,
    val isUrgent: Boolean = false,
    val source: String = "GPI Admin / BTEB (Demo)"
)

data class ClassRoutineItem(
    val id: String,
    val dayEn: String,
    val dayBn: String,
    val timeSlot: String,
    val subjectCode: String,
    val subjectNameEn: String,
    val subjectNameBn: String,
    val teacherNameEn: String,
    val teacherNameBn: String,
    val roomNo: String,
    val department: Department,
    val semester: Int,
    val shift: Shift
)

data class ExamRoutineItem(
    val id: String,
    val dateEn: String,
    val dateBn: String,
    val dayEn: String,
    val dayBn: String,
    val timeSlot: String,
    val examTypeEn: String,
    val examTypeBn: String,
    val subjectCode: String,
    val subjectNameEn: String,
    val subjectNameBn: String,
    val room: String,
    val department: Department,
    val semester: Int
)

data class SyllabusSubject(
    val code: String,
    val nameEn: String,
    val nameBn: String,
    val credits: Int,
    val theoryHours: Int,
    val practicalHours: Int,
    val department: Department,
    val semester: Int,
    val descriptionEn: String,
    val descriptionBn: String,
    val books: List<String>
)

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val isError: Boolean = false
)

enum class ScreenRoute {
    HOME,
    AI_TUTOR,
    NOTES,
    SYLLABUS,
    CLASS_ROUTINE,
    EXAM_ROUTINE,
    NOTICE_BOARD,
    CGPA_CALCULATOR,
    ATTENDANCE_TRACKER,
    STUDENT_PROFILE
}
